import Layout from '../src/components/Layout'

export default function About() {
  return (
    <Layout>
      <main className="container">
        <h2>About</h2>
        <p>This is a small philately catalog demo inspired by Empire Philatelists.</p>
      </main>
    </Layout>
  )
}
