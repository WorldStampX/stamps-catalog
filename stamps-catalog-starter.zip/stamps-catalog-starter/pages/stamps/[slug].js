import Layout from '../../src/components/Layout'
import { getAllStamps, getStampBySlug } from '../../src/lib/airtable'
import Image from 'next/image'
import Link from 'next/link'

export default function StampPage({ stamp }) {
  if (!stamp) return <Layout><p>Not found</p></Layout>

  const img = stamp.fields.Images && stamp.fields.Images[0] && stamp.fields.Images[0].url

  return (
    <Layout>
      <div className="product">
        <div className="gallery">
          {stamp.fields.Images && stamp.fields.Images.map((im, i) => (
            <img key={i} src={im.url} alt={stamp.fields.Title} />
          ))}
        </div>
        <div className="details">
          <h1>{stamp.fields.Title}</h1>
          <p className="price">{stamp.fields.Price ? `AUD ${stamp.fields.Price}` : ''}</p>
          <p className="meta">
            {stamp.fields.Year_Issued && <span>{stamp.fields.Year_Issued} • </span>}
            {stamp.fields.Condition && <span>{stamp.fields.Condition} • </span>}
            {stamp.fields['Catalogue References'] && <span>{stamp.fields['Catalogue References']}</span>}
          </p>
          <div className="description" dangerouslySetInnerHTML={{ __html: stamp.fields.Description || '' }} />
          <div className="actions">
            {stamp.fields['eBay URL'] && (
              <a className="btn" href={stamp.fields['eBay URL']} target="_blank" rel="noreferrer">View on eBay</a>
            )}
          </div>
          {stamp.fields.Status === 'Sold' && <div className="badge sold">Sold</div>}
        </div>
      </div>
    </Layout>
  )
}

export async function getStaticPaths() {
  const stamps = await getAllStamps()
  const paths = stamps.map(s => ({ params: { slug: s.fields.Slug } }))
  return { paths, fallback: 'blocking' }
}

export async function getStaticProps({ params }) {
  const stamp = await getStampBySlug(params.slug)
  if (!stamp) return { notFound: true }
  return { props: { stamp }, revalidate: 300 }
}
