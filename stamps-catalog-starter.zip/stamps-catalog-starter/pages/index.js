import Link from 'next/link'
import { getAllStamps } from '../src/lib/airtable'
import StampCard from '../src/components/StampCard'
import Layout from '../src/components/Layout'

export default function Home({ stamps }) {
  return (
    <Layout>
      <header className="hero">
        <h1>Empire-style Philately</h1>
        <p>Curated stamps — browse the catalog</p>
      </header>

      <main className="container">
        <section className="grid">
          {stamps.map(stamp => (
            <StampCard key={stamp.id} stamp={stamp} />
          ))}
        </section>
      </main>
    </Layout>
  )
}

export async function getStaticProps() {
  const stamps = await getAllStamps()
  return {
    props: { stamps },
    revalidate: 300
  }
}
