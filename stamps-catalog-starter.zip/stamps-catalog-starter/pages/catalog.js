import { getAllStamps } from '../src/lib/airtable'
import Layout from '../src/components/Layout'
import StampCard from '../src/components/StampCard'

export default function Catalog({ stamps }) {
  return (
    <Layout>
      <main className="container">
        <h2>Catalog</h2>
        <section className="grid">
          {stamps.map(s => <StampCard key={s.id} stamp={s} />)}
        </section>
      </main>
    </Layout>
  )
}

export async function getStaticProps() {
  const stamps = await getAllStamps()
  return { props: { stamps }, revalidate: 300 }
}
