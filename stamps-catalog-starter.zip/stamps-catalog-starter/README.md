# Stamps Catalog Starter (Next.js + Airtable)

This is a **read-only** stamp catalog starter site (Next.js) that pulls data from Airtable.
Design is minimal and inspired by Empire Philatelists.

## What it includes
- Home page with grid of stamps
- Individual stamp detail pages
- Airtable integration (reads `Stamps` table)
- "View on eBay" button per product

## How to use

1. Create a GitHub repository and upload this project.
2. In Netlify, connect the repo (New site from Git).
3. Add these environment variables in Netlify (Site settings → Build & deploy → Environment):
   - `AIRTABLE_API_KEY` (your Airtable personal access token)
   - `AIRTABLE_BASE_ID` (your Airtable base ID)
   - `AIRTABLE_TABLE_NAME` (default: `Stamps`)
4. Trigger a deploy. Netlify will run `npm run build`.

## Notes
- The project expects your Airtable `Stamps` table to have fields:
  - `Slug` (text)
  - `Title`
  - `Description`
  - `Price`
  - `Images` (Attachments)
  - `eBay URL`
  - `Status`
- It is read-only. No checkout or write operations are implemented.

## Local dev
- Install dependencies: `npm install`
- Run dev server: `npm run dev`

