import Link from 'next/link'

export default function Layout({ children }) {
  return (
    <div>
      <nav className="nav">
        <div className="brand"><Link href="/"><a>Empire-style Philately</a></Link></div>
        <div className="navlinks">
          <Link href="/catalog"><a>Catalog</a></Link>
          <Link href="/about"><a>About</a></Link>
          <a href="mailto:you@example.com">Contact</a>
        </div>
      </nav>
      {children}
      <footer className="footer">
        <p>© {new Date().getFullYear()} Empire-style Philately</p>
      </footer>
    </div>
  )
}
