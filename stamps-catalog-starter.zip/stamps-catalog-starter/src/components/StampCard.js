import Link from 'next/link'

export default function StampCard({ stamp }) {
  const img = stamp.fields.Images && stamp.fields.Images[0] && stamp.fields.Images[0].url
  return (
    <article className="card">
      <Link href={`/stamps/${stamp.fields.Slug}`}>
        <a>
          <div className="thumb">
            {img ? <img src={img} alt={stamp.fields.Title} /> : <div className="placeholder">No image</div>}
          </div>
          <div className="info">
            <h3>{stamp.fields.Title}</h3>
            <p className="price">{stamp.fields.Price ? `AUD ${stamp.fields.Price}` : ''}</p>
          </div>
        </a>
      </Link>
    </article>
  )
}
