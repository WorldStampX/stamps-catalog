/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['dl.airtableusercontent.com'],
  },
}
module.exports = nextConfig
